package ExcelLibrary;

import java.util.ArrayList;
import java.util.List;

public class TestExcelLibrary {

    private static final String FILE_NAME = "C:/Subhash/MarsWorkspace/excel2/MyFirstExcel.xlsx";

    public static void main(String[] args) {
    	try
    	{
    		
	    	List <String> data = new ArrayList<String>();
	    	List <String> row = new ArrayList<String>();
	    	//List<List<String>> Data;// = new ArrayList<String>();
	    	
	    	List<List<String>> Data = new ArrayList<List<String>>();
	    	ExcelDataHandler handler = new ExcelDataHandler();
	    	handler.Initialize(FILE_NAME);
	    	//handler.ReadOneRow(0, 5, data);
	    	data.add("Cathy");
	    	data.add("United");
	    	data.add("Bank");
	    	//handler.WriteOneRow("NewSheet1", data);
	    	
	    	for(int i=0;i<15;i++)
	    	{
	    		handler.WriteOneRow("NewSheet1", data);
	    	}
	    	
	    	
	    	/*for(int i=0;i<data.size();i++)
	    	{
	    		System.out.print("Value=" + data.get(i));
	    	}
	    	*/
	    	
    	}
    	catch (Exception e) {
            e.printStackTrace();
        }
    	
    }

}
